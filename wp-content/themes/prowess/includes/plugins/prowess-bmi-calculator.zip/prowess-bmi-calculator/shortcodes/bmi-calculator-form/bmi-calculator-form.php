<?php
namespace ProwessBmiCalculator\Shortcodes;

use ProwessBmiCalculator\Lib\ShortcodeInterface;

class BmiCalculatorForm implements ShortcodeInterface {
	private $base;

	/**
	 * BmiCalculatorForm constructor.
	 */
	public function __construct() {
		$this->base = 'prowess_bmi_calculator';

		add_action('vc_before_init', array($this, 'vcMap'));
	}


	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => esc_html__('Prowess BMI Calculator Form', ''),
			'base'                      => $this->base,
			'category'                  => esc_html__('By Select', ''),
			'icon'                      => 'icon-wpb-prowess-bmi-form extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__('Display BMI Chart', 'prowess-bmi-calculator'),
					'param_name'  => 'display_chart',
					'admin_label' => true,
					'value'       => array(
						esc_html__('Yes', 'prowess-bmi-calculator') => 'yes',
						esc_html__('No', 'prowess-bmi-calculator')  => 'no'
					),
					'save_always' => true
				),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Skin', 'prowess-bmi-calculator'),
                    'param_name' => 'skin',
                    'value' => array(
	                    esc_html__('Default', 'prowess-bmi-calculator') => '',
	                    esc_html__('Without Border', 'prowess-bmi-calculator') => 'without-border',
                    )
                ),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('BMI Chart Title', 'prowess-bmi-calculator'),
					'param_name'  => 'chart_title',
					'admin_label' => true,
					'value'       => '',
					'save_always' => true
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Form Title', 'prowess-bmi-calculator'),
					'param_name'  => 'form_title',
					'admin_label' => true,
					'value'       => '',
					'save_always' => true
				),
				array(
					'type'        => 'textarea',
					'heading'     => esc_html__('Form Description', 'prowess-bmi-calculator'),
					'param_name'  => 'form_description',
					'admin_label' => true,
					'value'       => '',
					'save_always' => true
				)
			)
		));
	}

	public function render($atts, $content = null) {
		$default_atts = array(
			'display_chart'    => '',
            'skin'             => '',
			'chart_title'      => '',
			'form_title'       => '',
			'form_description' => ''
		);

		$params = shortcode_atts($default_atts, $atts);

		$params['holder_classes']       = $this->getHolderClasses( $params );

		return prowess_bmi_get_template_part('shortcodes/bmi-calculator-form/templates/bmi-calculator-form-template', '', $params, true);
	}

	public function getHolderClasses( $params ) {
		$classes = array();

		$classes[] = ! empty( $params['skin'] ) ? 'qodef-bmi-calculator-' . $params['skin'] : '';

		return implode( ' ', $classes );
	}
}