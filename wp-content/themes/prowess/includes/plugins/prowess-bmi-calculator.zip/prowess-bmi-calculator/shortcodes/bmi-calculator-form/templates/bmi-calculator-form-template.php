<div class="qodef-bmi-calculator-holder qodef-grid-row qodef-grid-large-gutter <?php echo esc_attr($holder_classes) ?>">
	<?php if($display_chart === 'yes') : ?>
		<div class="qodef-bmic-table-holder qodef-grid-col-6">
			<?php if($chart_title !== '') : ?>
				<div class="qodef-section-title-holder">
					<h3 class="qodef-section-title qodef-section-title-medium"><?php echo esc_html($chart_title); ?></h3>
				</div>
			<?php endif; ?>
			<table>
				<thead>
				<tr>
					<th><?php esc_html_e('BMI', 'prowess-bmi-calculator'); ?></th>
					<th><?php esc_html_e('Weight Status', 'prowess-bmi-calculator'); ?></th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td><?php esc_html_e('Below', 'prowess-bmi-calculator'); ?> 18.5</td>
					<td><?php esc_html_e('Underweight', 'prowess-bmi-calculator'); ?></td>
				</tr>
				<tr>
					<td>18.5 - 24.9</td>
					<td><?php esc_html_e('Healthy', 'prowess-bmi-calculator'); ?></td>
				</tr>
				<tr>
					<td>25.0 - 29.9</td>
					<td><?php esc_html_e('Overweight', 'prowess-bmi-calculator'); ?></td>
				</tr>
				<tr>
					<td>30.0 - <?php esc_html_e('and Above', 'prowess-bmi-calculator'); ?></td>
					<td><?php esc_html_e('Obese', 'prowess-bmi-calculator'); ?></td>
				</tr>
				</tbody>
			</table>
			<div class="qodef-bmic-legend">
				<span>
				<sup>*</sup> <span class="qodef-bmic-legend-bold"><?php esc_html_e('BMR', 'prowess-bmi-calculator') ?></span> <?php esc_html_e('Metabolic Rate', 'prowess-bmi-calculator') ?> / <span class="qodef-bmic-legend-bold"><?php esc_html_e('BMI', 'prowess-bmi-calculator') ?></span> <?php esc_html_e('Body Mass Index', 'prowess-bmi-calculator') ?>
				</span>
			</div>
		</div>
	<?php endif; ?>
	<div class="qodef-bmic-form-holder qodef-grid-col-6">
		<?php if($form_title !== '') : ?>
			<div class="qodef-section-title-holder">
				<h3 class="qodef-section-title qodef-section-title-medium"><?php echo esc_html($form_title); ?></h3>
			</div>
		<?php endif; ?>
		<div class="qodef-section-subtitle-holder">
			<div class="qodef-section-subtitle">
				<p><?php echo esc_html($form_description); ?></p>
			</div>
		</div>
		<form action="POST" class="qodef-bmic-form">
			<div class="qodef-grid-row qodef-grid-small-gutter">
				<div class="qodef-grid-col-6">
					<input type="text" name="height" placeholder="<?php esc_attr_e('Height / cm', 'prowess-bmi-calculator'); ?>">
				</div>
				<div class="qodef-grid-col-6">
					<input type="text" name="weight" placeholder="<?php esc_attr_e('Weight / kg', 'prowess-bmi-calculator'); ?>">
				</div>
                <div class="qodef-grid-col-6">
					<input type="text" name="age" placeholder="<?php esc_attr_e('Age', 'prowess-bmi-calculator'); ?>">
				</div>
                <div class="qodef-grid-col-6">
					<select class="qodef-bmi-select2" name="sex">
						<option value=""><?php esc_html_e('Sex', 'prowess-bmi-calculator'); ?></option>
						<option value="male"><?php esc_html_e('Male', 'prowess-bmi-calculator'); ?></option>
						<option value="female"><?php esc_html_e('Female', 'prowess-bmi-calculator'); ?></option>
					</select>
				</div>
                <div class="qodef-grid-col-12">
					<select class="qodef-bmi-select2" name="activity_level">
						<option value=""><?php esc_html_e('Select an activity factor:', 'prowess-bmi-calculator'); ?></option>
						<option value="little"><?php esc_html_e('Little or no Exercise/ desk job', 'prowess-bmi-calculator'); ?></option>
						<option value="light"><?php esc_html_e('Light exercise/ sports 1 – 3 days/ week', 'prowess-bmi-calculator'); ?></option>
						<option value="moderate"><?php esc_html_e('Moderate Exercise, sports 3 – 5 days/ week', 'prowess-bmi-calculator'); ?></option>
						<option value="heavy"><?php esc_html_e('Heavy Exercise/ sports 6 – 7 days/ week', 'prowess-bmi-calculator'); ?></option>
						<option value="very_heavy"><?php esc_html_e('Very heavy exercise/ physical job/ training 2 x/ day', 'prowess-bmi-calculator'); ?></option>
					</select>
				</div>
                <div class="qodef-grid-col-12">
                    <?php

                    if ( prowess_select_core_plugin_installed() ) {
	                    echo prowess_select_get_button_html(
                            array(
                                'html_type' => 'button',
                                'type'      => 'solid',
                                'size'      => 'small',
                                'icon_pack' => 'ion_icons',
                                'ion_icon'  => 'ion-arrow-right-c',
                                'text'      => esc_html__('Calculate', 'prowess-bmi-calculator')
                            )
	                    );
                    } else {
	                    echo '<button class="qodef-btn qodef-btn-solid qodef-btn-small">';
	                    echo '<span class="qodef-btn-text">' . esc_html__('Calculate', 'prowess-bmi-calculator') . '</span>';
	                    echo '<i class="qodef-icon-ion-icon ion-arrow-right-c"<</i>';
	                    echo '</button>';
                    }

                    ?>
				</div>
			</div>
		</form>
	</div>
	<div class="qodef-grid-col-12">
		<div class="qodef-bmic-notifications">
			<span class="qodef-bmic-icon-holder">
				<span></span>
			</span>
			<span class="qodef-bmic-notification-text"></span>
			<a href="#" class="qodef-bmic-notification-close"></a>
		</div>
	</div>
</div>