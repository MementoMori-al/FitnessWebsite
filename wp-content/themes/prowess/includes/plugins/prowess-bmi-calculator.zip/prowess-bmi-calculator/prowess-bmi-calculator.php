<?php
/*
Plugin Name: Prowess BMI Calculator
Description: Plugin that adds BMI calculator functionality to our theme
Author: Prowess Themes
Version: 1.2.2
*/

include_once 'load.php';

if ( ! function_exists( 'qode_bmi_calculator_text_domain' ) ) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function qode_bmi_calculator_text_domain() {
		load_plugin_textdomain( 'prowess-bmi-calculator', false, PROWESS_BMI_CALCULATOR_REL_PATH . '/languages' );
	}

	add_action( 'plugins_loaded', 'qode_bmi_calculator_text_domain' );
}

use ProwessBmiCalculator\Lib;

Lib\ShortcodeLoader::getInstance()->load();