<?php

define('PROWESS_BMI_CALCULATOR_VERSION', '1.2.2');
define('PROWESS_BMI_CALCULATOR_ABS_PATH', dirname(__FILE__));
define('PROWESS_BMI_CALCULATOR_REL_PATH', dirname(plugin_basename(__FILE__ )));