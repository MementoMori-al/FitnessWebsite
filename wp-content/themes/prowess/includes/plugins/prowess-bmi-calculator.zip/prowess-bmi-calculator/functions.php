<?php
use ProwessBmiCalculator\Lib\BmiCalculatorApi;


if(!function_exists('prowess_bmi_load_assets')) {
	function prowess_bmi_load_assets() {
		
		$array_deps_css            = array();
		$array_deps_css_responsive = array();
		$array_deps_js             = array();

		if ( prowess_bmi_theme_installed() ) {
			$array_deps_css[]            = 'prowess-style-handle-modules';
			$array_deps_css_responsive[] = 'prowess-style-handle-modules-responsive';
			$array_deps_js[]             = 'prowess-script_handle-modules';
			$array_deps_js[]             = 'prowess-script-handle-google-map-api';
			$array_deps_js[]             = 'select2';
			$array_deps_js[]             = 'rangeslider';
		}
		
		wp_enqueue_style( 'prowess-bmi-calculator-style', plugins_url( '/assets/css/bmi-calculator.min.css', __FILE__ ), $array_deps_css );
		wp_enqueue_script('prowess-bmi-calculator-script', plugins_url('/assets/js/bmi-calculator.js', __FILE__), array('jquery'), '', true);
		wp_enqueue_script( 'select2', plugins_url('assets/js/plugins/select2.min.js',__FILE__ ), array('jquery'), false, true );
	}

	add_action('wp_enqueue_scripts', 'prowess_bmi_load_assets');
}