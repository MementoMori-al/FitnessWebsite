<?php

if ( ! function_exists( 'prowess_core_reviews_map' ) ) {
	function prowess_core_reviews_map() {
		
		$reviews_panel = prowess_select_add_admin_panel(
			array(
				'title' => esc_html__( 'Reviews', 'prowess-core' ),
				'name'  => 'panel_reviews',
				'page'  => '_page_page'
			)
		);
		
		prowess_select_add_admin_field(
			array(
				'parent'      => $reviews_panel,
				'type'        => 'text',
				'name'        => 'reviews_section_title',
				'label'       => esc_html__( 'Reviews Section Title', 'prowess-core' ),
				'description' => esc_html__( 'Enter title that you want to show before average rating for each room', 'prowess-core' ),
			)
		);
		
		prowess_select_add_admin_field(
			array(
				'parent'      => $reviews_panel,
				'type'        => 'textarea',
				'name'        => 'reviews_section_subtitle',
				'label'       => esc_html__( 'Reviews Section Subtitle', 'prowess-core' ),
				'description' => esc_html__( 'Enter subtitle that you want to show before average rating for each room', 'prowess-core' ),
			)
		);
		
		do_action( 'prowess_hotel_room_action_single_fields' );
	}
	
	add_action( 'prowess_select_additional_page_options_map', 'prowess_core_reviews_map', 75 ); //one after elements
}