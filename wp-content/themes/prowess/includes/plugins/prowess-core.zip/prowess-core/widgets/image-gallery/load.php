<?php

include_once PROWESS_CORE_ABS_PATH . '/widgets/image-gallery/functions.php';
include_once PROWESS_CORE_ABS_PATH . '/widgets/image-gallery/image-gallery.php';