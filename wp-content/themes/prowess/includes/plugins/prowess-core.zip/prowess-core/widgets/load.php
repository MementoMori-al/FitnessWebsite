<?php

if ( ! function_exists( 'prowess_select_load_widget_class' ) ) {
	/**
	 * Loades widget class file.
	 */
	function prowess_select_load_widget_class() {
		include_once PROWESS_CORE_ABS_PATH . '/widgets/lib/widget-class.php';
	}
	
	add_action( 'prowess_select_before_options_map', 'prowess_select_load_widget_class' );
}


if ( ! function_exists( 'prowess_select_load_widgets' ) ) {
	/**
	 * Loades all widgets by going through all folders that are placed directly in widgets folder
	 * and loads load.php file in each. Hooks to prowess_select_after_options_map action
	 */
	function prowess_select_load_widgets() {
		
		foreach ( glob( PROWESS_CORE_ABS_PATH . '/widgets/*/load.php' ) as $widget_load ) {
			include_once $widget_load;
		}
		
		include_once PROWESS_CORE_ABS_PATH . '/widgets/lib/widget-loader.php';
	}
	
	add_action( 'prowess_select_before_options_map', 'prowess_select_load_widgets' );
}
