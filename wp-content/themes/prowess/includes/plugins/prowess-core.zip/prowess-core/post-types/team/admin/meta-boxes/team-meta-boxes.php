<?php

if ( ! function_exists( 'prowess_core_map_team_single_meta' ) ) {
	function prowess_core_map_team_single_meta() {
		
		$meta_box = prowess_select_create_meta_box(
			array(
				'scope' => 'team-member',
				'title' => esc_html__( 'Team Member Info', 'prowess-core' ),
				'name'  => 'team_meta'
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Position', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s role within the team', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_birth_date',
				'type'        => 'date',
				'label'       => esc_html__( 'Birth date', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s birth date', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_email',
				'type'        => 'text',
				'label'       => esc_html__( 'Email', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s email', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_phone',
				'type'        => 'text',
				'label'       => esc_html__( 'Phone', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s phone', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_address',
				'type'        => 'text',
				'label'       => esc_html__( 'Address', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s addres', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_education',
				'type'        => 'text',
				'label'       => esc_html__( 'Education', 'prowess-core' ),
				'description' => esc_html__( 'The members\'s education', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_team_member_resume',
				'type'        => 'file',
				'label'       => esc_html__( 'Resume', 'prowess-core' ),
				'description' => esc_html__( 'Upload members\'s resume', 'prowess-core' ),
				'parent'      => $meta_box
			)
		);
		
		for ( $x = 1; $x < 6; $x ++ ) {
			
			$social_icon_group = prowess_select_add_admin_group(
				array(
					'name'   => 'qodef_team_member_social_icon_group' . $x,
					'title'  => esc_html__( 'Social Link ', 'prowess-core' ) . $x,
					'parent' => $meta_box
				)
			);
			
			$social_row1 = prowess_select_add_admin_row(
				array(
					'name'   => 'qodef_team_member_social_icon_row1' . $x,
					'parent' => $social_icon_group
				)
			);
			
			ProwessIconCollections::get_instance()->getIconsMetaBoxOrOption(
				array(
					'label'            => esc_html__( 'Icon ', 'prowess-core' ) . $x,
					'parent'           => $social_row1,
					'name'             => 'qodef_team_member_social_icon_pack_' . $x,
					'defaul_icon_pack' => '',
					'type'             => 'meta-box',
					'field_type'       => 'simple'
				)
			);
			
			$social_row2 = prowess_select_add_admin_row(
				array(
					'name'   => 'qodef_team_member_social_icon_row2' . $x,
					'parent' => $social_icon_group
				)
			);
			
			prowess_select_create_meta_box_field(
				array(
					'type'            => 'textsimple',
					'label'           => esc_html__( 'Link', 'prowess-core' ),
					'name'            => 'qodef_team_member_social_icon_' . $x . '_link',
					'parent'          => $social_row2,
					'dependency' => array(
						'hide' => array(
							'qodef_team_member_social_icon_pack_'. $x  => ''
						)
					)
				)
			);
			
			prowess_select_create_meta_box_field(
				array(
					'type'            => 'selectsimple',
					'label'           => esc_html__( 'Target', 'prowess-core' ),
					'name'            => 'qodef_team_member_social_icon_' . $x . '_target',
					'options'         => prowess_select_get_link_target_array(),
					'parent'          => $social_row2,
					'dependency' => array(
						'hide' => array(
							'qodef_team_member_social_icon_' . $x . '_link'  => ''
						)
					)
				)
			);
		}
	}
	
	add_action( 'prowess_select_meta_boxes_map', 'prowess_core_map_team_single_meta', 46 );
}