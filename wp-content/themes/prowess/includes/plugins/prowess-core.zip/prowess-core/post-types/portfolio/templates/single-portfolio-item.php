<?php

get_header();

prowess_select_get_title();

do_action('prowess_select_before_main_content');

prowess_core_get_single_portfolio();

get_footer();