<?php

if ( ! function_exists( 'prowess_core_map_testimonials_meta' ) ) {
	function prowess_core_map_testimonials_meta() {
		$testimonial_meta_box = prowess_select_create_meta_box(
			array(
				'scope' => array( 'testimonials' ),
				'title' => esc_html__( 'Testimonial', 'prowess-core' ),
				'name'  => 'testimonial_meta'
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_testimonial_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'prowess-core' ),
				'description' => esc_html__( 'Enter testimonial title', 'prowess-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_testimonial_text',
				'type'        => 'text',
				'label'       => esc_html__( 'Text', 'prowess-core' ),
				'description' => esc_html__( 'Enter testimonial text', 'prowess-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_testimonial_author',
				'type'        => 'text',
				'label'       => esc_html__( 'Author', 'prowess-core' ),
				'description' => esc_html__( 'Enter author name', 'prowess-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		prowess_select_create_meta_box_field(
			array(
				'name'        => 'qodef_testimonial_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Author Position', 'prowess-core' ),
				'description' => esc_html__( 'Enter author job position', 'prowess-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
	}
	
	add_action( 'prowess_select_meta_boxes_map', 'prowess_core_map_testimonials_meta', 95 );
}