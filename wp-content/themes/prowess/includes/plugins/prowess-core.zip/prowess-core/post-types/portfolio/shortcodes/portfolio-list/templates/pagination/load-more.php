<?php if($query_results->max_num_pages > 1) {
	$holder_styles = $this_object->getLoadMoreStyles($params);
	?>
	<div class="qodef-pl-loading">
		<div class="qodef-pl-loading-bounce1"></div>
		<div class="qodef-pl-loading-bounce2"></div>
		<div class="qodef-pl-loading-bounce3"></div>
	</div>
	<div class="qodef-pl-load-more-holder">
		<div class="qodef-pl-load-more" <?php prowess_select_inline_style($holder_styles); ?>>
			<?php 
				echo prowess_select_get_button_html(array(
					'link' => 'javascript: void(0)',
					'text' => esc_html__('LOAD MORE', 'prowess-core'),
                    'icon_pack' => 'ion_icons',
					'ion_icon' => 'ion-arrow-right-c'
				));
			?>
		</div>
	</div>
<?php }