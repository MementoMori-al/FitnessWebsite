<?php if(prowess_select_core_plugin_installed() && prowess_select_options()->getOptionValue('enable_social_share') == 'yes' && prowess_select_options()->getOptionValue('enable_social_share_on_portfolio-item') == 'yes') : ?>
    <div class="qodef-ps-info-item qodef-ps-social-share">
        <h6 class="qodef-ps-info-title-social"><?php esc_html_e('Share', 'prowess-core'); ?></h6>
        <?php echo prowess_select_get_social_share_html() ?>
    </div>
<?php endif; ?>