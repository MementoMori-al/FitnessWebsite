<?php
get_header();
prowess_select_get_title();
do_action( 'prowess_select_before_main_content' ); ?>
<div class="qodef-container qodef-default-page-template">
	<?php do_action( 'prowess_select_after_container_open' ); ?>
	<div class="qodef-container-inner clearfix">
		<?php
			$prowess_taxonomy_id   = get_queried_object_id();
			$prowess_taxonomy_type = is_tax( 'portfolio-tag' ) ? 'portfolio-tag' : 'portfolio-category';
			$prowess_taxonomy      = ! empty( $prowess_taxonomy_id ) ? get_term_by( 'id', $prowess_taxonomy_id, $prowess_taxonomy_type ) : '';
			$prowess_taxonomy_slug = ! empty( $prowess_taxonomy ) ? $prowess_taxonomy->slug : '';
			$prowess_taxonomy_name = ! empty( $prowess_taxonomy ) ? $prowess_taxonomy->taxonomy : '';
			
			prowess_core_get_archive_portfolio_list( $prowess_taxonomy_slug, $prowess_taxonomy_name );
		?>
	</div>
	<?php do_action( 'prowess_select_before_container_close' ); ?>
</div>
<?php get_footer(); ?>
