<?php

if ( ! function_exists( 'prowess_core_map_portfolio_meta' ) ) {
	function prowess_core_map_portfolio_meta() {
		global $prowess_Framework;
		
		$qode_pages = array();
		$pages      = get_pages();
		foreach ( $pages as $page ) {
			$qode_pages[ $page->ID ] = $page->post_title;
		}
		
		//Portfolio Images
		
		$qodePortfolioImages = new ProwessMetaBox( 'portfolio-item', esc_html__( 'Portfolio Images (multiple upload)', 'prowess-core' ), '', '', 'portfolio_images' );
		$prowess_Framework->qodeMetaBoxes->addMetaBox( 'portfolio_images', $qodePortfolioImages );
		
		$prowess_portfolio_image_gallery = new ProwessMultipleImages( 'qodef-portfolio-image-gallery', esc_html__( 'Portfolio Images', 'prowess-core' ), esc_html__( 'Choose your portfolio images', 'prowess-core' ) );
		$qodePortfolioImages->addChild( 'qodef-portfolio-image-gallery', $prowess_portfolio_image_gallery );
		
		//Portfolio Single Upload Images/Videos 
		
		$prowess_portfolio_images_videos = prowess_select_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Portfolio Images/Videos (single upload)', 'prowess-core' ),
				'name'  => 'qodef_portfolio_images_videos'
			)
		);
		prowess_select_add_repeater_field(
			array(
				'name'        => 'qodef_portfolio_single_upload',
				'parent'      => $prowess_portfolio_images_videos,
				'button_text' => esc_html__( 'Add Image/Video', 'prowess-core' ),
				'fields'      => array(
					array(
						'type'        => 'select',
						'name'        => 'file_type',
						'label'       => esc_html__( 'File Type', 'prowess-core' ),
						'options' => array(
							'image' => esc_html__('Image','prowess-core'),
							'video' => esc_html__('Video','prowess-core'),
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'single_image',
						'label'       => esc_html__( 'Image', 'prowess-core' ),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'image'
							)
						)
					),
					array(
						'type'        => 'select',
						'name'        => 'video_type',
						'label'       => esc_html__( 'Video Type', 'prowess-core' ),
						'options'	  => array(
							'youtube' => esc_html__('YouTube', 'prowess-core'),
							'vimeo' => esc_html__('Vimeo', 'prowess-core'),
							'self' => esc_html__('Self Hosted', 'prowess-core'),
						),
						'dependency' => array(
							'show' => array(
								'file_type'  => 'video'
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_id',
						'label'       => esc_html__( 'Video ID', 'prowess-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => array('youtube','vimeo')
							)
						)
					),
					array(
						'type'        => 'text',
						'name'        => 'video_mp4',
						'label'       => esc_html__( 'Video mp4', 'prowess-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					),
					array(
						'type'        => 'image',
						'name'        => 'video_cover_image',
						'label'       => esc_html__( 'Video Cover Image', 'prowess-core' ),
						'dependency' => array(
							'show' => array(
								'file_type' => 'video',
								'video_type'  => 'self'
							)
						)
					)
				)
			)
		);
		
		//Portfolio Additional Sidebar Items
		
		$qodeAdditionalSidebarItems = prowess_select_create_meta_box(
			array(
				'scope' => array( 'portfolio-item' ),
				'title' => esc_html__( 'Additional Portfolio Sidebar Items', 'prowess-core' ),
				'name'  => 'portfolio_properties'
			)
		);

		prowess_select_add_repeater_field(
			array(
				'name'        => 'qodef_portfolio_properties',
				'parent'      => $qodeAdditionalSidebarItems,
				'button_text' => esc_html__( 'Add New Item', 'prowess-core' ),
				'fields'      => array(
					array(
						'type'        => 'text',
						'name'        => 'item_title',
						'label'       => esc_html__( 'Item Title', 'prowess-core' ),
					),
					array(
						'type'        => 'text',
						'name'        => 'item_text',
						'label'       => esc_html__( 'Item Text', 'prowess-core' )
					),
					array(
						'type'        => 'text',
						'name'        => 'item_url',
						'label'       => esc_html__( 'Enter Full URL for Item Text Link', 'prowess-core' )
					)
				)
			)
		);
	}
	
	add_action( 'prowess_select_meta_boxes_map', 'prowess_core_map_portfolio_meta', 40 );
}