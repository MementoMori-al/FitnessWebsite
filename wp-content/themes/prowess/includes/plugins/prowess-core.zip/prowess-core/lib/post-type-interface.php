<?php

namespace ProwessCore\Lib;

/**
 * interface PostTypeInterface
 * @package ProwessCore\Lib;
 */
interface PostTypeInterface {
	/**
	 * @return string
	 */
	public function getBase();
	
	/**
	 * Registers custom post type with WordPress
	 */
	public function register();
}