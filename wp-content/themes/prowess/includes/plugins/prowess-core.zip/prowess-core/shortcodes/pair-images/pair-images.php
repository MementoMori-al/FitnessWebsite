<?php

namespace ProwessCore\CPT\Shortcodes\PairImages;

use ProwessCore\Lib;

class PairImages implements Lib\ShortcodeInterface {
	private $base;

	function __construct() {
		$this->base = 'qodef_pair_images';

		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map( array(
					'name'     => esc_html__( 'Pair Images', 'prowess-core' ),
					'base'     => $this->base,
					'category' => esc_html__( 'By Select', 'prowess-core' ),
					'icon'     => 'icon-wpb-pair-images extended-custom-icon',
					'params'   => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'prowess-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'prowess-core' )
						),
						array(
							'type'       => 'attach_image',
							'param_name' => 'item_big_image',
							'heading'    => esc_html__( 'Big Image', 'prowess-core' )
						),
						array(
							'type'       => 'attach_image',
							'param_name' => 'item_small_image',
							'heading'    => esc_html__( 'Small Image', 'prowess-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'layout',
							'heading'    => esc_html__( 'Layout order', 'prowess-core' ),
							'value'      => array(
								esc_html__( 'Small Image On The Left', 'prowess-core' ) => '',
								esc_html__( 'Big Image On The Left', 'prowess-core' )   => 'qodef-big-image-first',
								esc_html__( 'Small Image On Top Right', 'prowess-core' )   => 'qodef-small-image-top-right',
								esc_html__( 'Small Image On Top Left', 'prowess-core' )   => 'qodef-small-image-top-left'
							)
						)
					)
				) );
		}
	}

	public function render( $atts, $content = null ) {
		$args   = array(
			'custom_class'          => '',
			'item_big_image'        => '',
			'item_small_image'      => '',
			'layout'                => ''
		);
		$params = shortcode_atts( $args, $atts );

		$params['holder_classes'] = $this->getHolderClasses( $params );

		$html = prowess_core_get_shortcode_module_template_part( 'templates/pair-images', 'pair-images', '', $params );

		return $html;
	}

	/**
	 * Return holder classes
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getHolderClasses( $params ) {
		$holderClasses = array();

		if ( ! empty( $params['layout'] ) ) {
			$holderClasses[] = $params['layout'];
		}

		return implode( ' ', $holderClasses );
	}

}