<div <?php prowess_select_class_attribute($holder_classes); ?>>

	<div class="qodef-info-box-inner">
		<div class="qodef-ib-front-holder">
			<div class="qodef-ib-front-holder-inner">
				<div class="qodef-ib-top-holder">
					<?php if(!empty($custom_icon) || !empty($icon) ) : ?>
						<div class="qodef-ib-icon-holder">
							<?php if(!empty($custom_icon)) : ?>
								<?php echo wp_get_attachment_image($custom_icon, 'full'); ?>
							<?php else:
							    echo prowess_select_icon_collections()->renderIcon($icon, $icon_pack, array(
								'icon_attributes' => array(
									'style' => $icon_styles
								)
							));
                            endif; ?>
						</div>
					<?php endif; ?>

					<?php if(!empty($title)) : ?>
						<div class="qodef-ib-title-holder">
							<<?php echo esc_attr($title_tag); ?> class="qodef-ib-title"><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
						</div>
					<?php endif; ?>
				</div>

				<div class="qodef-ib-bottom-holder">
					<?php if(!empty($text)) : ?>
						<div class="qodef-ib-text-holder">
							<p><?php echo esc_html($text); ?></p>
						</div>
					<?php endif; ?>

					<?php if(is_array($button_params) && count($button_params)) : ?>
						<div class="qodef-ib-button-holder">
							<?php echo prowess_select_get_button_html($button_params); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

		</div>



		<div class="qodef-ib-overlay" <?php prowess_select_inline_style($holder_styles); ?>></div>
	</div>
</div>