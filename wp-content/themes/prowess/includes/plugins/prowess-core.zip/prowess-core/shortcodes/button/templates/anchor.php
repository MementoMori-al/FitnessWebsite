<a itemprop="url" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>" <?php prowess_select_inline_style($button_styles); ?> <?php prowess_select_class_attribute($button_classes); ?> <?php echo prowess_select_get_inline_attrs($button_data); ?> <?php echo prowess_select_get_inline_attrs($button_custom_attrs); ?>>
    <span class="qodef-btn-text"><span class="qodef-btn-text-inner"><?php echo esc_html($text); ?></span></span>
    <span class="qodef-btn-text-inner qodef-btn-text-inner-icon">
    	<?php echo prowess_select_icon_collections()->renderIcon($icon, $icon_pack); ?>
    	<?php echo prowess_select_icon_collections()->renderIcon($icon, $icon_pack); ?>	
    </span>
</a>