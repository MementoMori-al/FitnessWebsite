<?php

include_once PROWESS_CORE_SHORTCODES_PATH . '/info-box/functions.php';
include_once PROWESS_CORE_SHORTCODES_PATH . '/info-box/info-box.php';