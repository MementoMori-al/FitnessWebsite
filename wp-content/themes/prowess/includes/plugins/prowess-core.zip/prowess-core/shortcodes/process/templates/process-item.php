<div <?php prowess_select_class_attribute($item_classes); ?>>
    <?php if(!empty($link)) { ?>
        <a class="qodef-pr-item-link" href="<?php echo esc_url($link) ?>" target="<?php echo esc_attr($target) ?>"></a>
    <?php } ?>
    <div class="qodef-pr-item-holder-inner  clearfix">
            <div class="qodef-pr-item-holder">
                <?php if (!empty($image)) : ?>
                    <div class="qodef-pr-item">

                        <?php if (!empty($number)) : ?>
                            <div class="qodef-pr-item-number">
                                <?php echo esc_html($number); ?>
                            </div>
                        <?php endif; ?>

                        <div class="qodef-pr-item-inner">
                            <?php echo wp_get_attachment_image($image, 'full'); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="qodef-pr-item icon">

                        <?php if (!empty($number)) : ?>
                            <div class="qodef-pr-item-number">
                                <?php echo esc_html($number); ?>
                            </div>
                        <?php endif; ?>
                        <div class="qodef-pr-item-inner" <?php prowess_select_inline_style($icon_styles) ?>>
                            <?php echo prowess_core_get_shortcode_module_template_part('templates/icon', 'process', '', array('icon_parameters' => $icon_parameters)); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        <div class="qodef-pr-item-content-holder">
            <?php if (!empty($title)) : ?>
                <div class="qodef-pr-item-title-holder">
                    <h5 class="qodef-pr-item-title"><?php echo esc_html($title); ?></h5>
                </div>
            <?php endif; ?>

            <?php if (!empty($text)) : ?>
                <div class="qodef-pr-item-text-holder">
                    <p><?php echo esc_html($text); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>