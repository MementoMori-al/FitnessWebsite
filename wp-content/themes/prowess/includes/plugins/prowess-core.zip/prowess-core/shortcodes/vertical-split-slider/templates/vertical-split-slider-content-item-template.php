<div class="qodef-vss-ms-section" <?php echo prowess_select_get_inline_attrs($content_data); ?> <?php prowess_select_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>