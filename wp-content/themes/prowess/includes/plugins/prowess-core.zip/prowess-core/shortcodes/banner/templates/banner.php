<div class="qodef-banner-holder <?php echo esc_attr($holder_classes); ?>">
    <div class="qodef-banner-image">
        <?php echo wp_get_attachment_image($image, 'full'); ?>
    </div>
    <div class="qodef-banner-text-holder" <?php echo prowess_select_get_inline_style($overlay_styles); ?>>
	    <div class="qodef-banner-text-outer">
		    <div class="qodef-banner-text-inner">
		        <?php if(!empty($title)) { ?>
		            <<?php echo esc_attr($title_tag); ?> class="qodef-banner-title" <?php echo prowess_select_get_inline_style($title_styles); ?>>
		                <?php echo wp_kses($title, array('span' => array('class' => true))); ?>
	                </<?php echo esc_attr($title_tag); ?>>
		        <?php } ?>
                <?php if(!empty($price)) { ?>
                    <h5 class="qodef-banner-price" <?php echo prowess_select_get_inline_style($price_styles); ?>>
                        <?php if(!empty($currency)) { ?><span class="qodef-banner-currency"><?php echo esc_attr($currency) ?></span><?php } ?><span class="qodef-banner-price-num"><?php echo esc_html($price); ?></span>
                    </h5>
                <?php } ?>
				<?php if(!empty($link) && !empty($link_text)) { ?>
                    <?php
                    echo prowess_select_return_button_html( $button_params );
                    ?>
		        <?php } ?>
			</div>
		</div>
	</div>
	<?php if (!empty($link)) { ?>
        <a itemprop="url" class="qodef-banner-link" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>"></a>
    <?php } ?>
</div>