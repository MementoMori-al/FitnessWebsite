<?php

namespace ProwessCore\CPT\Shortcodes\Tabs;

use ProwessCore\Lib;

class TabsItem implements Lib\ShortcodeInterface {
	private $base;

	function __construct() {
		$this->base = 'qodef_tabs_item';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map( array(
					'name'            => esc_html__( 'Tabs Item', 'prowess-core' ),
					'base'            => $this->getBase(),
					'as_parent'       => array( 'except' => 'vc_row' ),
					'as_child'        => array( 'only' => 'qodef_tabs' ),
					'category'        => esc_html__( 'By Select', 'prowess-core' ),
					'icon'            => 'icon-wpb-tabs-item extended-custom-icon',
					'content_element' => true,
					'js_view'         => 'VcColumnView',
					'params'          => array(
						array(
							'type'       => 'textfield',
							'param_name' => 'tab_title',
							'heading'    => esc_html__( 'Title', 'prowess-core' )
						),
						array(
							'type'        => 'attach_image',
							'param_name'  => 'background_image',
							'heading'     => esc_html__( 'Background Image', 'prowess-core' ),
							'description' => '',
							'admin_label' => true
						)
					)
				) );
		}
	}

	public function render( $atts, $content = null ) {
		$default_atts = array(
			'tab_title'        => 'Tab',
			'tab_id'           => '',
			'background_image' => ''
		);
		$params       = shortcode_atts( $default_atts, $atts );

		$rand_number           = rand( 0, 1000 );
		$params['tab_title']   = $params['tab_title'] . '-' . $rand_number;
		$params['content']     = $content;
		$params['tab_styles']  = $this->getImageStyles( $params );
		$params['tab_classes'] = $this->getTabClasses( $params );

		$output = prowess_core_get_shortcode_module_template_part( 'templates/tab-content', 'tabs', '', $params );

		return $output;
	}

	private function getImageStyles( $params ) {
		$styles = array();

		if ( $params['background_image'] != '' ) {
			$styles[] = 'background-image: url(' . wp_get_attachment_url( $params['background_image'] ) . ')';
		}

		return $styles;
	}

	private function getTabClasses( $params ) {
		$classes = array( 'qodef-tab-container' );

		if ( $params['background_image'] != '' ) {
			$classes[] = 'qodef-tab-image';
		}

		return $classes;
	}
}