<div class="qodef-event-list-holder <?php echo esc_attr($holder_classes); ?>">
    <?php
    $i = 1;
    if($query_results->have_posts()):
        while ( $query_results->have_posts() ) : $query_results->the_post();
            //if ($i%4 == 1 || $i%4 == 2) {
	            echo prowess_core_get_shortcode_module_template_part( 'templates/event-list-item', 'event-list', '', $params );
            //} else {
	            //echo prowess_core_get_shortcode_module_template_part( 'templates/event-list-item-inverted', 'event-list', '', $params );
            //}
	        //$i++;
        endwhile;
    else:
        echo prowess_core_get_shortcode_module_template_part('templates/event-list-item', 'event-list');
    endif;
    wp_reset_postdata();
    ?>
</div>