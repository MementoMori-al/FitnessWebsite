(function ($) {
    'use strict';

    var infoBox = {};
    qodef.modules.infoBox = infoBox;

    infoBox.qodefInfoBox = qodefInfoBox;


    infoBox.qodefOnDocumentReady = qodefOnDocumentReady;

    $(document).ready(qodefOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
        qodefInfoBox();
    }


    function qodefInfoBox() {
        var infoBoxes = $('.qodef-info-box-holder');

        var getBottomHeight = function (bottomHolder) {
            if (bottomHolder.length) {
                return bottomHolder.height();
            }

            return false;
        }

        var infoBoxesHeight = function () {
            if (infoBoxes.length) {

                infoBoxes.each(function () {
                    var bottomHolder = $(this).find('.qodef-ib-bottom-holder');
                    var topHolder = $(this).find('.qodef-ib-top-holder')

                    var currentHeight = getBottomHeight(bottomHolder) + topHolder.height();

                    $(this).height(currentHeight);
                    topHolder.css('margin-top', getBottomHeight(bottomHolder) / 2 + "px");
                });
            }
        }

        var initHover = function (infoBox) {
        }

        if (infoBoxes.length) {
            infoBoxesHeight();

            $(qodef.window).resize(function () {
                infoBoxesHeight();
            });

            infoBoxes.each(function () {
                var thisInfoBox = $(this);
                initHover(thisInfoBox);

                $(qodef.window).resize(function () {
                    initHover(thisInfoBox);
                });
            });
        }
    }


})(jQuery);