<div class="qodef-event-list-read-more-button">
	<?php

	echo prowess_select_get_button_html( apply_filters( 'prowess_select_blog_template_read_more_button', array(
		'type'         => 'simple',
		'size'         => 'small',
		'link'         => get_the_permalink(),
		'text'         => esc_html__( 'Read More', 'prowess-core' ),
		'icon_pack'    => 'ion_icons',
		'ion_icon'     => 'ion-arrow-right-c',
		'custom_class' => ''
	) ) ); ?>

</div>
