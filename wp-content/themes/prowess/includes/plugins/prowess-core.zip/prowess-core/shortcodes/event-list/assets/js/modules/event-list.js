(function($) {
	'use strict';
	
	var eventList = {};
	qodef.modules.eventList = eventList;

	eventList.qodefIniteventList = qodefIniteventList;


	eventList.qodefOnDocumentReady = qodefOnDocumentReady;
	
	$(document).ready(qodefOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function qodefOnDocumentReady() {
		qodefIniteventList();
	}

	/*
	 **	Init Expanded Gallery shortcode
	 */
	function qodefIniteventList(){
		var holder = $('.qodef-event-list-item-holder');

		if(holder.length){
			holder.each(function() {
				var thisHolder 		= $(this),
					thisHolderImage = thisHolder.find('.qodef-event-list-item-image-inner'),
					thisHolderTitle = thisHolder.find('.qodef-event-list-item-title');

				
					thisHolderTitle.on('mouseenter mouseleave', function () {
						thisHolder.toggleClass('qodef-event-list-item-hover');
					});

			});
		}
	}
	
})(jQuery);