<div <?php prowess_select_class_attribute($holder_classes); ?>>
	<div class="qodef-process-inner clearfix">
        <?php echo do_shortcode($content); ?>
	</div>
</div>