<?php

include_once PROWESS_CORE_SHORTCODES_PATH . '/pair-images/functions.php';
include_once PROWESS_CORE_SHORTCODES_PATH . '/pair-images/pair-images.php';