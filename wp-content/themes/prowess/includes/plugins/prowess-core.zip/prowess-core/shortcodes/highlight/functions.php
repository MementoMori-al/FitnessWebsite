<?php

if ( ! function_exists( 'prowess_core_add_highlight_shortcodes' ) ) {
	function prowess_core_add_highlight_shortcodes( $shortcodes_class_name ) {
		$shortcodes = array(
			'ProwessCore\CPT\Shortcodes\Highlight\Highlight'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'prowess_core_filter_add_vc_shortcode', 'prowess_core_add_highlight_shortcodes' );
}