<?php

include_once PROWESS_CORE_SHORTCODES_PATH . '/event-list/functions.php';
include_once PROWESS_CORE_SHORTCODES_PATH . '/event-list/event-list.php';