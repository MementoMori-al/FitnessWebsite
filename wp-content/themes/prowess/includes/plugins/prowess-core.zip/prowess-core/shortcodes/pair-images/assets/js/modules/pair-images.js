(function($) {
    'use strict';

    var pairImages = {};
    qodef.modules.pairImages = pairImages;

    pairImages.qodefOnDocumentReady = qodefOnDocumentReady;
    pairImages.qodefOnWindowLoad = qodefOnWindowLoad;
    pairImages.qodefOnWindowResize = qodefOnWindowResize;
    pairImages.qodefOnWindowScroll = qodefOnWindowScroll;

    $(document).ready(qodefOnDocumentReady);
    $(window).on('load',qodefOnWindowLoad);
    $(window).resize(qodefOnWindowResize);
    $(window).scroll(qodefOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function qodefOnDocumentReady() {
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function qodefOnWindowLoad() {
        qodefParallaxElements();

    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function qodefOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function qodefOnWindowScroll() {
    }

    /**
     * Parallax Elements Instances
     */
    function qodefParallaxElements() {
        var parallaxElements = $('.qodef-pi-inner');

        if (parallaxElements.length && !qodef.htmlEl.hasClass('touch')) {
            parallaxElements.each(function(){
                var parallaxElement = $(this),
                    randCoeff = (Math.floor(Math.random()) + 1 ) * 0.07,
                    delta = -Math.round(parallaxElement.height() * randCoeff),
                    dataParallax = '{"y":'+delta+', "smoothness":20}',
                    dataParallaxSmall = '{"y":'+delta*2.5+', "smoothness":20}';

                if(parallaxElement.parent('.qodef-small-pair-item')){
                    parallaxElement.attr('data-parallax', dataParallaxSmall);
                }    
                else { 
                    parallaxElement.attr('data-parallax', dataParallax);
                }
            });

            setTimeout(function(){
                ParallaxScroll.init(); //initialzation removed from plugin js file to have it run only on non-touch devices
            }, 100); //wait for calcs
        }
    }

})(jQuery);
