<div class="qodef-pi-holder <?php echo esc_attr( $holder_classes ); ?>">

    <div class="qodef-pi qodef-small-pair-item">
        <div class="qodef-pi-inner">
            <div class="qodef-pi-image">
				<?php
				echo wp_get_attachment_image( $item_small_image, 'prowess_qodef_square' );
				?>
            </div>
        </div>
    </div>

    <div class="qodef-pi qodef-big-pair-item">
        <div class="qodef-pi-inner">
            <div class="qodef-pi-image">
				<?php
				echo wp_get_attachment_image( $item_big_image, 'prowess_qodef_portrait' );
				?>
            </div>
        </div>
    </div>
</div>
