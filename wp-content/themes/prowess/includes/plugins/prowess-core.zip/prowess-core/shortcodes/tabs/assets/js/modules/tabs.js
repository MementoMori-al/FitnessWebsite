(function($) {
	'use strict';
	
	var tabs = {};
	qodef.modules.tabs = tabs;
	
	tabs.qodefInitTabs = qodefInitTabs;
	
	
	tabs.qodefOnDocumentReady = qodefOnDocumentReady;
	
	$(document).ready(qodefOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function qodefOnDocumentReady() {
		qodefInitTabs();
	}
	
	/*
	 **	Init tabs shortcode
	 */
	function qodefInitTabs(){
		var tabs = $('.qodef-tabs');
		
		if(tabs.length){
			tabs.each(function(){
				var thisTabs = $(this);
				
				//vertical tabs
				if (thisTabs.hasClass('qodef-tabs-vertical')) {
					var tab = thisTabs.find('> ul > li'),
						tabLine = thisTabs.find('.qodef-tab-line');

					tabLine.css({height: tab.first().outerHeight()});
					tabLine.css({top: 0});

					tab.each(function () {
						var thisTab = $(this);
						thisTab.mouseenter(function () {
							tabLine.css({height: thisTab.outerHeight()});
							tabLine.css({top: thisTab.offset().top - thisTab.parent().offset().top});
						});
					});

					thisTabs.find('> ul').mouseleave(function () {
						tabLine.css({height: tab.filter('.ui-tabs-active').outerHeight()});
						tabLine.css({top: tab.filter('.ui-tabs-active').offset().top - tab.filter('.ui-tabs-active').parent().offset().top});
					});
				}

				thisTabs.children('.qodef-tab-container').each(function(index){
					index = index + 1;
					var that = $(this),
						link = that.attr('id'),
						navItem = that.parent().find('.qodef-tabs-nav li:nth-child('+index+') a'),
						navLink = navItem.attr('href');
					
					link = '#'+link;

					if(link.indexOf(navLink) > -1) {
						navItem.attr('href',link);
					}
				});

				thisTabs.tabs();

                $('.qodef-tabs a.qodef-external-link').off('click');
			});
		}
	}
	
})(jQuery);